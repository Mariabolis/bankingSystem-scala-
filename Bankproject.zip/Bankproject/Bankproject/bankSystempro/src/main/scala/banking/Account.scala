package banking

case class Account( id: Option[Int],cId: Int, balance: Int)